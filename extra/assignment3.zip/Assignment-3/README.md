# CSCB20-Assignment-2
We created the frontend for the course CSCB63 - Design and Analysis of Data for an assignment in the course CSCB20.
